

```
python procedural_path.py --screen_x=500 --screen_y=500

```